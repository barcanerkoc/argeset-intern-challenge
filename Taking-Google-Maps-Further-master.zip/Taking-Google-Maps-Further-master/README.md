Getting Creative With the Google Maps API
==========================

You’ve designed a shiny new website; carefully selecting the colors, typography and photographs to perfectly reflect the company’s branding.  Then your client asks you to add a map. Sure, you could use a map building ‘wizard’, such as the one that comes with every google account. But, let’s face it, their functionality is limited and they look pretty generic!
Read more http://enva.to/10DbGdf
